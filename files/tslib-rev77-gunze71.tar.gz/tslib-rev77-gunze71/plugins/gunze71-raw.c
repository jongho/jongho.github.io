#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

#include "config.h"
#include "tslib-private.h"

/* 
 FORMAT: T 0123 , 4567 <LF>
 INDEX:  0 1234 5 6789 0
*/

#define TS_PACKET_SIZE 11

static int gunze71_read(struct tslib_module_info *inf, struct ts_sample *samp, int nr)
{
	struct tsdev *ts = inf->dev;
	char *data;
	int ret;
	int total = 0;
	int i;

	data = alloca(TS_PACKET_SIZE * (nr + 1));
	ret = read(ts->fd, data, TS_PACKET_SIZE * (nr + 1));

	for(i = 0; i < TS_PACKET_SIZE; i++) {
		if(data[0] == 'T' || data[0] == 'R')
			break;
		data++;
		ret--;
	}

	if(ret > 0) {
		i = 0;
		while(ret >= TS_PACKET_SIZE && i < nr) {
			data[5] = '\0';
			data[10] = '\0';

			samp->x = (short)atoi(&data[1]);
			samp->y = (short)atoi(&data[6]);

			if(data[0]=='T')
				samp->pressure = 1;
			else if(data[0] == 'R')
				samp->pressure = 0;
			else
				return -1;

#ifdef DEBUG
        fprintf(stderr,"RAW---------------------------> %d %d %d\n",samp->x,samp->y,samp->pressure);
#endif /*DEBUG*/
			gettimeofday(&samp->tv,NULL);
			samp++;
			data += TS_PACKET_SIZE;
			ret -= TS_PACKET_SIZE;
			i++;
		}
	} else {
		return -1;
	}

	ret = nr;
	return ret;
}

static const struct tslib_ops gunze71_ops =
{
	.read	= gunze71_read,
};

TSAPI struct tslib_module_info *mod_init(struct tsdev *dev, const char *params)
{
	struct tslib_module_info *m;

	m = malloc(sizeof(struct tslib_module_info));
	if (m == NULL)
		return NULL;

	m->ops = &gunze71_ops;
	return m;
}
